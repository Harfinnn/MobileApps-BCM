import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Dimensions,
  ActivityIndicator,
  InteractionManager,
} from 'react-native'; // <-- Tambahkan InteractionManager
import { BarChart } from 'react-native-gifted-charts';

interface CobChartProps {
  chartData: any;
}

const CobChart: React.FC<CobChartProps> = ({ chartData }) => {
  const screenWidth = Dimensions.get('window').width;

  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let isMounted = true;

    // 1. Tunggu sampai FlatList benar-benar selesai bergeser/animasi
    const task = InteractionManager.runAfterInteractions(() => {
      if (isMounted) setIsReady(true);
    });

    // 2. Fallback aman maksimal 1 detik jika HP pengguna sedang berat/freeze
    const fallbackTimer = setTimeout(() => {
      if (isMounted) setIsReady(true);
    }, 1000);

    return () => {
      isMounted = false;
      task.cancel();
      clearTimeout(fallbackTimer);
    };
  }, []);

  // --- KONDISI PENTING: TAMPILKAN LOADING SAAT DELAY ---
  if (!isReady) {
    return (
      <View
        style={{
          height: 250,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#0D1117',
          borderRadius: 12,
          marginTop: 10,
        }}
      >
        <ActivityIndicator size="small" color="#20A090" />
      </View>
    );
  }
  // -------------------------------------------------------------------

  if (!chartData || !chartData.datasets || chartData.datasets.length < 1) {
    return <Text style={{ color: 'red' }}>Data grafik tidak valid</Text>;
  }

  // --- HELPERS ---
  const cleanNumber = (val: any) => {
    if (val === null || val === undefined) return 0;
    if (typeof val === 'number') return val;
    if (typeof val === 'string') {
      const cleanStr = val.replace(/[^0-9.-]+/g, '');
      return Number(cleanStr) || 0;
    }
    return 0;
  };

  const formatMinutesToHHMM = (minutes: number) => {
    if (!minutes || isNaN(minutes)) return '00:00';
    const h = Math.floor(minutes / 60)
      .toString()
      .padStart(2, '0');
    const m = Math.round(minutes % 60)
      .toString()
      .padStart(2, '0');
    return `${h}:${m}`;
  };

  const formatToJuta = (val: any) => {
    const num = cleanNumber(val);
    if (num === 0) return 0;
    if (num <= 1000) return Number(num.toFixed(2));
    return Number((num / 1000000).toFixed(2));
  };

  const normalizeDuration = (val: any) => {
    if (!val) return 0;
    if (typeof val === 'string' && val.includes(':')) {
      const parts = val.split(':').map(Number);
      return parts.length === 2
        ? parts[0] * 60 + parts[1]
        : parts[0] * 60 + parts[1] + Math.round((parts[2] || 0) / 60);
    }
    const num = cleanNumber(val);
    if (num > 0)
      return num > 100000
        ? Math.round(num / 60000)
        : num > 1440
        ? Math.round(num / 60)
        : num;
    return 0;
  };

  const findDataset = (keywords: string[]) =>
    chartData.datasets.find((ds: any) =>
      keywords.some(kw => (ds.name || '').toLowerCase().includes(kw)),
    );
  let barDataset = findDataset([
    'transaction',
    'transaksi',
    'volume',
    'actual',
    'aktual',
  ]) ||
    chartData.datasets[0] || { data: [] };
  let lineDataset =
    findDataset(['duration', 'durasi', 'waktu']) ||
    (chartData.datasets.length > 1 ? chartData.datasets[1] : { data: [] });

  // --- SKALA KIRI (BATANG) ---
  const maxTrx =
    barDataset.data && barDataset.data.length > 0
      ? Math.max(...barDataset.data.map(formatToJuta))
      : 0;
  let leftStep = Math.ceil(maxTrx / 3.5);
  if (leftStep < 1) leftStep = 1;
  const chartMaxValue = leftStep * 4;

  const leftYAxisLabels = [
    '0',
    `${leftStep} Jt`,
    `${leftStep * 2} Jt`,
    `${leftStep * 3} Jt`,
    `${chartMaxValue} Jt`,
  ];

  // --- SKALA KANAN (GARIS) ---
  const lineValues =
    lineDataset.data && lineDataset.data.length > 0
      ? lineDataset.data.map(normalizeDuration)
      : [0];
  const maxLineMinutes = Math.max(...lineValues);
  const minLineMinutes = Math.min(...lineValues);

  const baseOffset = Math.max(0, Math.floor((minLineMinutes - 30) / 30) * 30);
  let spread = maxLineMinutes - baseOffset;
  if (spread <= 0) spread = 60;
  const virtualTotalRange = spread / 0.6;

  let niceInterval = Math.ceil(virtualTotalRange / 4 / 30) * 30;
  if (niceInterval < 30) niceInterval = 30;
  const virtualMaxLine = baseOffset + niceInterval * 4;
  const scaleRatio = chartMaxValue / (virtualMaxLine - baseOffset);

  const rightYAxisLabels = [
    formatMinutesToHHMM(baseOffset),
    formatMinutesToHHMM(baseOffset + niceInterval),
    formatMinutesToHHMM(baseOffset + niceInterval * 2),
    formatMinutesToHHMM(baseOffset + niceInterval * 3),
    formatMinutesToHHMM(virtualMaxLine),
  ];

  // =========================================================================
  // FILTER CATATAN (FOOTNOTES)
  // =========================================================================
  const notesData = (chartData.labels || [])
    .map((lbl: string, i: number) => ({
      label: lbl,
      ket:
        chartData.keterangan && chartData.keterangan[i]
          ? chartData.keterangan[i]
          : '',
    }))
    .filter((n: any) => n.ket && n.ket.trim() !== '');

  // --- MAPPING DATA BARCHART (DENGAN TANDA BINTANG) ---
  const barData = (chartData.labels || []).map(
    (label: string, index: number) => {
      const rawVal = barDataset.data ? barDataset.data[index] : 0;
      const valJt = formatToJuta(rawVal);

      const ket =
        chartData.keterangan && chartData.keterangan[index]
          ? chartData.keterangan[index]
          : '';
      const hasKet = ket.trim().length > 0;

      return {
        value: valJt,
        labelComponent: () => (
          <Text
            style={{
              color: hasKet ? '#FFC107' : '#ccc',
              fontSize: 9,
              marginTop: 5,
              textAlign: 'center',
            }}
          >
            {label}
            {hasKet ? '*' : ''}
          </Text>
        ),
        frontColor: '#20A090',
        topLabelComponent: () => (
          <Text
            style={{
              color: '#fff',
              fontSize: 9,
              fontWeight: 'bold',
              width: 50,
              textAlign: 'center',
              marginLeft: -13,
              marginBottom: 4,
              textShadowColor: 'rgba(0,0,0,0.8)',
              textShadowOffset: { width: 1, height: 1 },
              textShadowRadius: 2,
            }}
          >
            {valJt} Jt
          </Text>
        ),
      };
    },
  );

  // --- MAPPING DATA LINECHART ---
  const lineData = lineValues.map((val: number) => ({
    value: Math.max(0, (val - baseOffset) * scaleRatio),
    customDataPoint: () => (
      <View style={{ alignItems: 'center', justifyContent: 'center' }}>
        <View
          style={{
            width: 8,
            height: 8,
            backgroundColor: '#FFC107',
            borderRadius: 4,
            borderWidth: 1,
            borderColor: '#0D1117',
            zIndex: 10,
          }}
        />
        <Text
          style={{
            color: '#FFC107',
            fontSize: 9,
            fontWeight: 'bold',
            position: 'absolute',
            top: 12,
            width: 50,
            textAlign: 'center',
            zIndex: 10,
            textShadowColor: 'rgba(0,0,0,0.9)',
            textShadowOffset: { width: 1, height: 1 },
            textShadowRadius: 3,
          }}
        >
          {formatMinutesToHHMM(val)}
        </Text>
      </View>
    ),
  }));

  return (
    <View
      style={{
        marginTop: 10,
        backgroundColor: '#0D1117',
        paddingVertical: 15,
        paddingLeft: 5,
        borderRadius: 12,
        overflow: 'hidden',
      }}
    >
      {chartData.title && (
        <Text
          style={{
            color: '#20A090',
            fontSize: 14,
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: 15,
          }}
        >
          {chartData.title}
        </Text>
      )}

      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          marginBottom: 25,
          gap: 20,
        }}
      >
        <LegendItem color="#20A090" label="Transaction" />
        <LegendItem color="#7B61FF" label="Duration" isCircle />
      </View>

      <View style={{ position: 'relative', paddingRight: 55 }}>
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            right: 0,
            top: 10,
            backgroundColor: '#0D1117',
            height: 230,
            width: 40,
            zIndex: 1,
          }}
        >
          {rightYAxisLabels.map((l: string, i: number) => (
            <Text
              key={i}
              style={{
                position: 'absolute',
                top: 200 - (i / 4) * 200 - 7,
                right: 5,
                color: '#ccc',
                fontSize: 10,
                textAlign: 'right',
              }}
            >
              {l}
            </Text>
          ))}
        </View>

        <BarChart
          data={barData}
          width={screenWidth * 0.55}
          height={200}
          isAnimated={false}
          barWidth={24}
          spacing={20}
          initialSpacing={40}
          endSpacing={40}
          noOfSections={4}
          maxValue={chartMaxValue}
          yAxisLabelTexts={leftYAxisLabels}
          yAxisThickness={0}
          xAxisColor="#444"
          yAxisLabelWidth={35}
          yAxisTextStyle={{ color: '#ccc', fontSize: 10 }}
          rulesType="dashed"
          rulesColor="#333"
          showLine
          lineData={lineData}
          lineConfig={{ color: '#7B61FF', thickness: 2 }}
        />
      </View>

      {/* FOOTNOTE */}
      {notesData.length > 0 && (
        <View
          style={{
            marginTop: 20,
            paddingTop: 15,
            paddingRight: 15,
            borderTopWidth: 1,
            borderColor: '#333',
          }}
        >
          <Text
            style={{
              color: '#fff',
              fontSize: 10,
              fontWeight: 'bold',
              marginBottom: 8,
            }}
          >
            Catatan Operasional:
          </Text>
          {notesData.map((n: any, i: number) => (
            <Text
              key={i}
              style={{
                color: '#aaa',
                fontSize: 9,
                marginBottom: 4,
                lineHeight: 13,
              }}
            >
              <Text style={{ color: '#FFC107', fontWeight: 'bold' }}>
                {n.label} * :{' '}
              </Text>
              {n.ket}
            </Text>
          ))}
        </View>
      )}
    </View>
  );
};

const LegendItem = ({ color, label, isCircle }: any) => (
  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
    <View
      style={{
        width: 12,
        height: 12,
        backgroundColor: color,
        borderRadius: isCircle ? 6 : 4,
      }}
    />
    <Text style={{ color: '#fff', fontSize: 11 }}>{label}</Text>
  </View>
);

export default CobChart;
