<?php

namespace App\Services;

use Google\Client as GoogleClient;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class FcmService
{
    protected static function getAccessToken()
    {
        $client = new GoogleClient();
        $client->setAuthConfig(base_path(config('services.firebase.credentials')));
        $client->addScope('https://www.googleapis.com/auth/firebase.messaging');

        $token = $client->fetchAccessTokenWithAssertion();

        return $token['access_token'];
    }

    public static function send(
        string $fcmToken,
        string $title,
        string $body,
        array $data = []
    ) {
        $accessToken = self::getAccessToken();

        // 🔒 PAKSA DATA STRING (WAJIB FCM)
        $safeData = [];
        foreach ($data as $key => $value) {
            $safeData[$key] = (string) $value;
        }

        $response = Http::withToken($accessToken)->post(
            'https://fcm.googleapis.com/v1/projects/' .
            config('services.firebase.project_id') .
            '/messages:send',
            [
                'message' => [
                    'token' => $fcmToken,

                    // 🔔 WAJIB UNTUK APK STANDALONE
                    'notification' => [
                        'title' => $title,
                        'body' => $body,
                    ],

                    // 📦 DATA TETAP DIKIRIM (UNTUK NAVIGASI)
                    'data' => $safeData,

                    'android' => [
                        'priority' => 'HIGH',
                    ],
                ],
            ]
        );

        if ($response->failed()) {
            $body = $response->json();

            if (
                isset($body['error']['details'][0]['errorCode']) &&
                $body['error']['details'][0]['errorCode'] === 'UNREGISTERED'
            ) {
                // 🔥 TOKEN MATI → HAPUS
                \App\Models\User::where('fcm_token', $fcmToken)
                    ->update(['fcm_token' => null]);
            }

            Log::error('FCM FAILED', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
        }
    }
}